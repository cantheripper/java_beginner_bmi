import java.util.Scanner;

public class Login {
    public boolean login(Hesap hesap){
        Scanner scanner = new Scanner(System.in);
        System.out.println("Lütfen kullanici adınızı giriniz:");
        String girilen_k_adi = scanner.nextLine();
        System.out.println("Lütfen parolanızı giriniz:");
        String girilen_parola = scanner.nextLine();
        if (hesap.getKullanici_adi().equals(girilen_k_adi) && hesap.getParola().equals(girilen_parola))
            return true;
        else
            return false;


    }
}
